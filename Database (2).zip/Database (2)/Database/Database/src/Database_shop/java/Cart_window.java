/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database_shop.java;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ann
 */
public class Cart_window extends javax.swing.JFrame
    {

    /**
     * Creates new form shopping_test
     */
    public Cart_window()
        {
        initComponents();

        }

    public static void AddData(Object[] user_cart)
        {

        DefaultTableModel tb = (DefaultTableModel) cartTable.getModel();

        tb.addRow(user_cart);
        tb.fireTableDataChanged();

        }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        cartTable = new javax.swing.JTable();
        RemoveBtn = new javax.swing.JButton();
        CheckoutBtn = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        UpdateBtn = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        SelBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(51, 51, 51));
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 204, 204));
        jPanel1.setForeground(new java.awt.Color(153, 153, 153));

        cartTable.setAutoCreateRowSorter(true);
        cartTable.setFont(new java.awt.Font("Cambria Math", 0, 14)); // NOI18N
        cartTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Product Name", "Product Quantity", "Size", "Product Price", "Total"
            }
        ));
        cartTable.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                cartTableFocusGained(evt);
            }
        });
        cartTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cartTableMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                cartTableMouseExited(evt);
            }
        });
        jScrollPane1.setViewportView(cartTable);

        RemoveBtn.setBackground(new java.awt.Color(204, 204, 255));
        RemoveBtn.setFont(new java.awt.Font("Cambria Math", 0, 14)); // NOI18N
        RemoveBtn.setText("Remove");
        RemoveBtn.setEnabled(false);
        RemoveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveBtnActionPerformed(evt);
            }
        });

        CheckoutBtn.setBackground(new java.awt.Color(204, 204, 255));
        CheckoutBtn.setFont(new java.awt.Font("Cambria Math", 0, 14)); // NOI18N
        CheckoutBtn.setText("Checkout");
        CheckoutBtn.setEnabled(false);
        CheckoutBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CheckoutBtnActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Cambria Math", 0, 14)); // NOI18N
        jLabel3.setText("Shopping Cart");

        UpdateBtn.setBackground(new java.awt.Color(204, 204, 255));
        UpdateBtn.setFont(new java.awt.Font("Cambria Math", 0, 14)); // NOI18N
        UpdateBtn.setText("Update");
        UpdateBtn.setEnabled(false);
        UpdateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateBtnActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(204, 204, 255));
        jButton1.setFont(new java.awt.Font("Cambria Math", 0, 14)); // NOI18N
        jButton1.setText("Go back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        SelBtn.setFont(new java.awt.Font("Cambria Math", 0, 14)); // NOI18N
        SelBtn.setText("Select All");
        SelBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(SelBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton1))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 520, Short.MAX_VALUE)
                    .addComponent(UpdateBtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(RemoveBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(CheckoutBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SelBtn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(UpdateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(RemoveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(CheckoutBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
 Shopping_window mf = new Shopping_window();

    String name1, name2, name3, name4, name5, name6;
    int skull, corset, over, string, silky, moon, stock = 0, s, m, l, xl, xxl, s1, m1, l1, xl1, xxl1, s2, m2, l2, xl2, xxl2, s3, m3, l3, xl3, xxl3, s4, m4, l4, xl4, xxl4, s5, m5, l5, xl5, xxl5;

    //method pang delete row
    public void delRows(JTable table)
        {
        DefaultTableModel tb = (DefaultTableModel) this.cartTable.getModel();
        int[] row_holder = table.getSelectedRows();
        for (int counter = 0; counter < row_holder.length; counter++)
            {
            tb.removeRow(row_holder[counter] - counter);
            tb.fireTableDataChanged();

            }
        }

    public void updateCart()
        {
        DefaultTableModel tb = (DefaultTableModel) this.cartTable.getModel();
        String filePath = "cartFile.txt";
        File file = new File(filePath);
        try
            {
            FileWriter fw = new FileWriter(file);
            BufferedWriter bw = new BufferedWriter(fw);

            for (int row = 0; row < cartTable.getRowCount(); row++)
                {//rows
                for (int col = 0; col < cartTable.getColumnCount(); col++)
                    {//columns
                    bw.write(cartTable.getValueAt(row, col).toString() + " ");
                    }
                bw.newLine();
                }
            bw.close();
            fw.close();

            } catch (IOException ex)
            {

            }

        }

    public void exportTotext()
        {
        //eto yung nageexport sa text file ng nasa cart na sinelect na iccheckout currently
        DefaultTableModel tb = (DefaultTableModel) this.cartTable.getModel();
        String filePath = "resibo.txt";
        File file = new File(filePath);
        try
            {
            FileWriter fw = new FileWriter(file);
            BufferedWriter bw = new BufferedWriter(fw);

            int[] cart_index = cartTable.getSelectedRows();
            for (int i = 0; i < cart_index.length; i++)
                {
                bw.write(tb.getValueAt(cart_index[i], 0).toString() + " " + tb.getValueAt(cart_index[i], 1).toString() + " " + tb.getValueAt(cart_index[i], 2).toString() + " " + tb.getValueAt(cart_index[i], 3).toString() + " " + tb.getValueAt(cart_index[i], 4).toString() + "\n");

                }
            bw.close();
            fw.close();

            } catch (IOException ex)
            {

            }

        }

    public void UpdateStockFile()
        //eto yung tagaupdate mismo ng stock file NOT YUNG SA TABLE
        {
        DefaultTableModel tb = (DefaultTableModel) cartTable.getModel();
        int rowIndex = cartTable.getSelectedRow();
        Shopping_window sw = new Shopping_window();
        try
            {

            //pang initialize ng mga name1 variables from stock.txt
            File stockFile = new File("stock.txt");
            Scanner sc = new Scanner(stockFile);
            while (sc.hasNextLine())
                {
                name1 = sc.next();
                skull = sc.nextInt();
                s = sc.nextInt();
                m = sc.nextInt();
                l = sc.nextInt();
                xl = sc.nextInt();
                xxl = sc.nextInt();
                name2 = sc.next();
                string = sc.nextInt();
                s1 = sc.nextInt();
                m1 = sc.nextInt();
                l1 = sc.nextInt();
                xl1 = sc.nextInt();
                xxl1 = sc.nextInt();
                name3 = sc.next();
                over = sc.nextInt();
                s2 = sc.nextInt();
                m2 = sc.nextInt();
                l2 = sc.nextInt();
                xl2 = sc.nextInt();
                xxl2 = sc.nextInt();
                name4 = sc.next();
                corset = sc.nextInt();
                s3 = sc.nextInt();
                m3 = sc.nextInt();
                l3 = sc.nextInt();
                xl3 = sc.nextInt();
                xxl3 = sc.nextInt();
                name5 = sc.next();
                silky = sc.nextInt();
                s4 = sc.nextInt();
                m4 = sc.nextInt();
                l4 = sc.nextInt();
                xl4 = sc.nextInt();
                xxl4 = sc.nextInt();
                name6 = sc.next();
                moon = sc.nextInt();
                s5 = sc.nextInt();
                m5 = sc.nextInt();
                l5 = sc.nextInt();
                xl5 = sc.nextInt();
                xxl5 = sc.nextInt();

                }

            //panginitialize sa nameko  (eto yung pagsstorean ng mga nasa cart na iccheckout basically yung resibo)
            File myfile = new File("resibo.txt");
            Scanner inFile = new Scanner(myfile);

            while (inFile.hasNextLine())
                {
                String nameko = inFile.next();
                int quantity = inFile.nextInt();
                String size = inFile.next();
                int price = inFile.nextInt();
                int total = inFile.nextInt();

                //pangupdate sa stock dapat na file mismo na base yung ibabawas sa stock(initial) dun sa resibo
                try
                    {
                    File origFile = new File("stock.txt");

                    FileWriter updateFile = new FileWriter(origFile, false);

                    if (nameko.equals("Croptop-Skull") && size.equals("Extra-Small"))
                        {
                        skull = skull - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Croptop-Skull") && size.equals("Small"))
                        {
                        s = s - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Croptop-Skull") && size.equals("Medium"))
                        {
                        m = m - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Croptop-Skull") && size.equals("Large"))
                        {
                        l = l - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }
                    else if (nameko.equals("Croptop-Skull") && size.equals("Extra-Large"))
                        {
                        xl = xl - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Croptop-Skull") && size.equals("Double-Extra-Large"))
                        {
                        xxl = xxl - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Red-String-Dress") && size.equals("Extra-Small"))
                        {
                        string = string - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Red-String-Dress") && size.equals("Small"))
                        {
                        s1 = s1 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Red-String-Dress") && size.equals("Medium"))
                        {
                        m1 = m1 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Red-String-Dress") && size.equals("Large"))
                        {
                        l1 = l1 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }
                    else if (nameko.equals("Red-String-Dress") && size.equals("Extra-Large"))
                        {
                        xl1 = xl1 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Red-String-Dress") && size.equals("Double-Extra-Large"))
                        {
                        xxl1 = xxl1 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Oversize-Tshirt-Mont.March") && size.equals("Extra-Small"))
                        {
                        over = over - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Oversize-Tshirt-Mont.March") && size.equals("Small"))
                        {
                        s2 = s2 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }
                    else if (nameko.equals("Oversize-Tshirt-Mont.March") && size.equals("Medium"))
                        {
                        m2 = m2 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Oversize-Tshirt-Mont.March") && size.equals("Large"))
                        {
                        l2 = l2 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Oversize-Tshirt-Mont.March") && size.equals("Extra-Large"))
                        {
                        xl2 = xl2 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Oversize-Tshirt-Mont.March") && size.equals("Double-Extra-Large"))
                        {
                        xxl2 = xxl2 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Corset-Top") && size.equals("Extra-Small"))
                        {
                        corset = corset - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Corset-Top") && size.equals("Small"))
                        {
                        s3 = s3 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }
                    else if (nameko.equals("Corset-Top") && size.equals("Medium"))
                        {
                        m3 = m3 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Corset-Top") && size.equals("Large"))
                        {
                        l3 = l3 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Corset-Top") && size.equals("Extra-Large"))
                        {
                        xl3 = xl3 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Corset-Top") && size.equals("Double-Extra-Large"))
                        {
                        xxl3 = xxl3 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Silky-Backless-Tie-Up") && size.equals("Extra-Small"))
                        {
                        silky = silky - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Silky-Backless-Tie-Up") && size.equals("Small"))
                        {
                        s4 = s4 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }
                    else if (nameko.equals("Silky-Backless-Tie-Up") && size.equals("Medium"))
                        {
                        m4 = m4 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Silky-Backless-Tie-Up") && size.equals("Large"))
                        {
                        l4 = l4 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Silky-Backless-Tie-Up") && size.equals("Extra-Large"))
                        {
                        xl4 = xl4 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Silky-Backless-Tie-Up") && size.equals("Double-Extra-Large"))
                        {
                        xxl4 = xxl4 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Moon-Graphic-Tee") && size.equals("Extra-Small"))
                        {
                        moon = moon - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Moon-Graphic-Tee") && size.equals("Small"))
                        {
                        s5 = s5 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }
                    else if (nameko.equals("Moon-Graphic-Tee") && size.equals("Medium"))
                        {
                        m5 = m5 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Moon-Graphic-Tee") && size.equals("Large"))
                        {
                        l5 = l5 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Moon-Graphic-Tee") && size.equals("Extra-Large"))
                        {
                        xl5 = xl5 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    else if (nameko.equals("Moon-Graphic-Tee") && size.equals("Double-Extra-Large"))
                        {
                        xxl5 = xxl5 - quantity;
                        updateFile.write("skull " + String.valueOf(skull) + " " + String.valueOf(s) + " " + String.valueOf(m) + " " + String.valueOf(l) + " " + String.valueOf(xl) + " " + String.valueOf(xxl));
                        updateFile.write("\nstring " + String.valueOf(string) + " " + String.valueOf(s1) + " " + String.valueOf(m1) + " " + String.valueOf(l1) + " " + String.valueOf(xl1) + " " + String.valueOf(xxl1));
                        updateFile.write("\noversize " + String.valueOf(over) + " " + String.valueOf(s2) + " " + String.valueOf(m2) + " " + String.valueOf(l2) + " " + String.valueOf(xl2) + " " + String.valueOf(xxl2));
                        updateFile.write("\ncorset " + String.valueOf(corset) + " " + String.valueOf(s3) + " " + String.valueOf(m3) + " " + String.valueOf(l3) + " " + String.valueOf(xl3) + " " + String.valueOf(xxl3));
                        updateFile.write("\nsilky " + String.valueOf(silky) + " " + String.valueOf(s4) + " " + String.valueOf(m4) + " " + String.valueOf(l4) + " " + String.valueOf(xl4) + " " + String.valueOf(xxl4));
                        updateFile.write("\nmoon " + String.valueOf(moon) + " " + String.valueOf(s5) + " " + String.valueOf(m5) + " " + String.valueOf(l5) + " " + String.valueOf(xl5) + " " + String.valueOf(xxl5));

                        }

                    updateFile.close();

                    } catch (Exception ex)
                    {
                    Logger.getLogger(login_page.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

            inFile.close();
            } catch (Exception e)
            {
            }
        }

    private void CheckoutBtnActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_CheckoutBtnActionPerformed
    {//GEN-HEADEREND:event_CheckoutBtnActionPerformed

        //eto yung tagakuha ng mga values sa colum ng total tapos pinagaadd lahat
        int sum = 0;

        for (int count = 0; count < Cart_window.cartTable.getRowCount(); count++)
            {
            sum = sum + Integer.parseInt(cartTable.getValueAt(count, 4).toString());
            }
        int pindot = JOptionPane.showConfirmDialog(null, "Your total is: " + sum + "\n" + "Are you sure?", "Check Out Window", JOptionPane.INFORMATION_MESSAGE);

        if (pindot == JOptionPane.OK_OPTION)
            {

            try
                {

                exportTotext();
                UpdateStockFile();
                delRows(cartTable);
                updateCart();

                } catch (Exception ex)
                {
                Logger.getLogger(Cart_window.class.getName()).log(Level.SEVERE, null, ex);
                }

            Shopping_window sw = new Shopping_window();
            sw.show();
            dispose();
            }
        dispose();
    }//GEN-LAST:event_CheckoutBtnActionPerformed

    private void RemoveBtnActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_RemoveBtnActionPerformed
    {//GEN-HEADEREND:event_RemoveBtnActionPerformed
        DefaultTableModel tb = (DefaultTableModel) cartTable.getModel();
        delRows(cartTable);
        updateCart();

    }//GEN-LAST:event_RemoveBtnActionPerformed

    public String getNewSizePrice()
        {
        DefaultTableModel tb = (DefaultTableModel) cartTable.getModel();

        int rowIndex = cartTable.getSelectedRow();

        if (cartTable.getValueAt(rowIndex, 2).toString().equals("small") || cartTable.getValueAt(rowIndex, 2).toString().equals("Small") || cartTable.getValueAt(rowIndex, 2).toString().equals("s") || cartTable.getValueAt(rowIndex, 2).toString().equals("S"))
            {

            cartTable.setValueAt(150, rowIndex, 3);
            }

        else if (cartTable.getValueAt(rowIndex, 2).toString().equals("medium") || cartTable.getValueAt(rowIndex, 2).toString().equals("Medium") || cartTable.getValueAt(rowIndex, 2).toString().equals("m") || cartTable.getValueAt(rowIndex, 2).toString().equals("M"))
            {

            cartTable.setValueAt(200, rowIndex, 3);
            }

        else if (cartTable.getValueAt(rowIndex, 2).toString().equals("extra-small") || cartTable.getValueAt(rowIndex, 2).toString().equals("Extra-Small") || cartTable.getValueAt(rowIndex, 2).toString().equals("xs") || cartTable.getValueAt(rowIndex, 2).toString().equals("XS"))
            {

            cartTable.setValueAt(100, rowIndex, 3);
            }

        else if (cartTable.getValueAt(rowIndex, 2).toString().equals("large") || cartTable.getValueAt(rowIndex, 2).toString().equals("Large") || cartTable.getValueAt(rowIndex, 2).toString().equals("l") || cartTable.getValueAt(rowIndex, 2).toString().equals("L"))
            {

            cartTable.setValueAt(250, rowIndex, 3);
            }

        else if (cartTable.getValueAt(rowIndex, 2).toString().equals("extra-large") || cartTable.getValueAt(rowIndex, 2).toString().equals("Extra-Large") || cartTable.getValueAt(rowIndex, 2).toString().equals("xl") || cartTable.getValueAt(rowIndex, 2).toString().equals("XL"))
            {

            cartTable.setValueAt(300, rowIndex, 3);
            }

        else if (cartTable.getValueAt(rowIndex, 2).toString().equals("double-extra-large") || cartTable.getValueAt(rowIndex, 2).toString().equals("Double-Extra-Large") || cartTable.getValueAt(rowIndex, 2).toString().equals("xxl") || cartTable.getValueAt(rowIndex, 2).toString().equals("Double-Extra-Large"))
            {

            cartTable.setValueAt(350, rowIndex, 3);
            }

        else
            {
            JOptionPane.showMessageDialog(null, "Not a valid size option!", "Check Out Window", JOptionPane.ERROR_MESSAGE);
            }

        return cartTable.getValueAt(rowIndex, 3).toString();

        }

    public String getNewSize(String new_size)
        {
        DefaultTableModel tb = (DefaultTableModel) cartTable.getModel();

        int rowIndex = cartTable.getSelectedRow();

        if (new_size.equals("small") || new_size.toString().equals("Small") || new_size.toString().equals("s") || new_size.toString().equals("S"))
            {

            cartTable.setValueAt("Small", rowIndex, 2);

            }

        else if (new_size.equals("medium") || new_size.toString().equals("Medium") || new_size.toString().equals("m") || new_size.toString().equals("M"))
            {
            cartTable.setValueAt("Medium", rowIndex, 2);

            }

        else if (new_size.equals("extra-small") || new_size.equals("Extra-Small") || new_size.equals("xs") || new_size.toString().equals("XS"))
            {
            cartTable.setValueAt("Extra-Small", rowIndex, 2);

            }

        else if (new_size.equals("large") || new_size.equals("Large") || new_size.equals("l") || new_size.equals("L"))
            {
            cartTable.setValueAt("Large", rowIndex, 2);

            }

        else if (new_size.equals("extra-large") || new_size.equals("Extra-Large") || new_size.equals("xl") || new_size.equals("XL"))
            {
            cartTable.setValueAt("Extra-Large", rowIndex, 2);

            }

        else if (new_size.equals("double-extra-large") || new_size.equals("Double-Extra-Large") || new_size.equals("xxl") || new_size.equals("Double-Extra-Large"))
            {
            cartTable.setValueAt("Double-Extra-Large", rowIndex, 2);

            }

        else
            {
            JOptionPane.showMessageDialog(null, "Not a valid size option!", "Check Out Window", JOptionPane.ERROR_MESSAGE);
            }

        return cartTable.getValueAt(rowIndex, 2).toString();
        }

    public int stockChecker(String pname, String size) throws FileNotFoundException
        {

        DefaultTableModel tb = (DefaultTableModel) cartTable.getModel();
        int rowIndex = cartTable.getSelectedRow();

        try
            {

            File myfile = new File("stock.txt");
            Scanner inFile = new Scanner(myfile);

            while (inFile.hasNextLine())
                {

                if (pname.equals("name1") && size.equals("Extra-Small"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();

                    stock = (skull);
                    }
                else if (pname.equals("name1") && size.equals("Small"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (s);

                    }
                else if (pname.equals("name1") && size.equals("Medium"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (m);

                    }
                else if (pname.equals("name1") && size.equals("Large"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (l);

                    }
                else if (pname.equals("name1") && size.equals("Extra-Large"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (xl);

                    }
                else if (pname.equals("name1") && size.equals("Double-Extra-Large"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (xxl);

                    }
                else if (pname.equals("name2") && size.equals("Extra-Small"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (string);

                    }
                else if (pname.equals("name2") && size.equals("Small"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (s1);

                    }
                else if (pname.equals("name2") && size.equals("Medium"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (m1);

                    }
                else if (pname.equals("name2") && size.equals("Large"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (l1);

                    }
                else if (pname.equals("name2") && size.equals("Extra-Large"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (xl1);

                    }
                else if (pname.equals("name2") && size.equals("Double-Extra-Large"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (xxl1);

                    }

                else if (pname.equals("name3") && size.equals("Extra-Small"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (over);

                    }
                else if (pname.equals("name3") && size.equals("Small"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (s2);

                    }
                else if (pname.equals("name3") && size.equals("Medium"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (m2);

                    }
                else if (pname.equals("name3") && size.equals("Large"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (l2);

                    }
                if (pname.equals("name3") && size.equals("Extra-Large"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (xl2);

                    }
                if (pname.equals("name3") && size.equals("Double-Extra-Large"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (xxl2);

                    }
                else if (pname.equals("name4") && size.equals("Extra-Small"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (corset);

                    }
                else if (pname.equals("name4") && size.equals("Small"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (s3);

                    }
                else if (pname.equals("name4") && size.equals("Medium"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (m3);

                    }
                else if (pname.equals("name4") && size.equals("Large"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (l3);

                    }
                else if (pname.equals("name4") && size.equals("Extra-Large"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (xl3);

                    }
                else if (pname.equals("name4") && size.equals("Double-Extra-Large"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (xxl3);

                    }
                else if (pname.equals("name5") && size.equals("Extra-Small"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (silky);

                    }
                else if (pname.equals("name5") && size.equals("Small"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (s4);

                    }
                else if (pname.equals("name5") && size.equals("Medium"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (m4);

                    }
                else if (pname.equals("name5") && size.equals("Large"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (l4);

                    }
                if (pname.equals("name5") && size.equals("Extra-Large"))
                    {
                     name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (xl4);

                    }
                else if (pname.equals("name5") && size.equals("Double-Extra-Large"))
                    {
                     name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    

                    stock = (xxl4);

                    }
                else if (pname.equals("name6") && size.equals("Extra-Small"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (moon);

                    }
                else if (pname.equals("name6") && size.equals("Small"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (s5);

                    }
                else if (pname.equals("name6") && size.equals("Medium"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (m5);

                    }
                else if (pname.equals("name6") && size.equals("Large"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (l5);

                    }
                if (pname.equals("name6") && size.equals("Extra-Large"))
                    {
                     name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                   

                    stock = (xl5);

                    }
                else if (pname.equals("name6") && size.equals("Double-Extra-Large"))
                    {
                    name1 = inFile.next();
                    skull = inFile.nextInt();
                    s = inFile.nextInt();
                    m = inFile.nextInt();
                    l = inFile.nextInt();
                    xl = inFile.nextInt();
                    xxl = inFile.nextInt();
                    name2 = inFile.next();
                    string = inFile.nextInt();
                    s1 = inFile.nextInt();
                    m1 = inFile.nextInt();
                    l1 = inFile.nextInt();
                    xl1 = inFile.nextInt();
                    xxl1 = inFile.nextInt();
                    name3 = inFile.next();
                    over = inFile.nextInt();
                    s2 = inFile.nextInt();
                    m2 = inFile.nextInt();
                    l2 = inFile.nextInt();
                    xl2 = inFile.nextInt();
                    xxl2 = inFile.nextInt();
                    name4 = inFile.next();
                    corset = inFile.nextInt();
                    s3 = inFile.nextInt();
                    m3 = inFile.nextInt();
                    l3 = inFile.nextInt();
                    xl3 = inFile.nextInt();
                    xxl3 = inFile.nextInt();
                    name5 = inFile.next();
                    silky = inFile.nextInt();
                    s4 = inFile.nextInt();
                    m4 = inFile.nextInt();
                    l4 = inFile.nextInt();
                    xl4 = inFile.nextInt();
                    xxl4 = inFile.nextInt();
                    name6 = inFile.next();
                    moon = inFile.nextInt();
                    s5 = inFile.nextInt();
                    m5 = inFile.nextInt();
                    l5 = inFile.nextInt();
                    xl5 = inFile.nextInt();
                    xxl5 = inFile.nextInt();
                    stock = (xxl5);


                    }
                return stock;
                }

            inFile.close();

            } catch (FileNotFoundException ex)
            {
            Logger.getLogger(Cart_window.class.getName()).log(Level.SEVERE, null, ex);
            }

        return stock;
        }


    private void UpdateBtnActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_UpdateBtnActionPerformed
    {//GEN-HEADEREND:event_UpdateBtnActionPerformed

        try
            {
            int spin_val = 0;
            int rowIndex = cartTable.getSelectedRow();

            String prod_quan = cartTable.getValueAt(rowIndex, 1).toString();
            String sizers = cartTable.getValueAt(rowIndex, 2).toString();

            switch (cartTable.getValueAt(rowIndex, 0).toString())
                {
                case "Croptop-Skull":
                    {
                    //input ng user para sa iuupdate na cart nakabase lang yung dami sa stock file

                    String size = cartTable.getValueAt(rowIndex, 2).toString();
                    int temp = stockChecker("name1", size);
                    SpinnerNumberModel sModel = new SpinnerNumberModel(1, 0, temp, 1);
                    JSpinner spinner = new JSpinner(sModel);
                    int pili = JOptionPane.showOptionDialog(null, spinner, "Enter valid number", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);

                    //dito nagccheck kapag babaguhin yung value ng quantity tapos iccheck kung may stock pa
                    if (pili == JOptionPane.OK_OPTION)
                        {
                        spin_val = Integer.parseInt(spinner.getValue().toString());
                            {
                            if (spin_val > temp || temp == 0 || spin_val == 1)
                                {
                                JOptionPane.showMessageDialog(null, "Insufficient stock at the moment", "Out of stock!", JOptionPane.WARNING_MESSAGE);
                                }
                            else
                                {
                                String real_sizers = JOptionPane.showInputDialog(null, "Input your desired size.", sizers);
                                String new_sp = cartTable.getValueAt(rowIndex, 3).toString();
                                //set ng values sa row (quantity, size, price, total)
                                cartTable.setValueAt(Integer.parseInt(spinner.getValue().toString()), rowIndex, 1);
                                cartTable.setValueAt(getNewSize(real_sizers), rowIndex, 2);
                                cartTable.setValueAt(getNewSizePrice(), rowIndex, 3);

                                //set ng total after changes
                                int new_price = Integer.parseInt(cartTable.getValueAt(rowIndex, 3).toString());
                                int new_quantity = Integer.parseInt(spinner.getValue().toString());
                                int new_total = new_price * new_quantity;
                                cartTable.setValueAt(new_total, rowIndex, 4);
                                }
                            }
                        }
                    break;
                    }
                case "Corset-Top":
                    {

                    String size = cartTable.getValueAt(rowIndex, 2).toString();
                    int temp = stockChecker("name4", size);
                    SpinnerNumberModel sModel = new SpinnerNumberModel(1, 0, temp, 1);
                    JSpinner spinner = new JSpinner(sModel);
                    int pili = JOptionPane.showOptionDialog(null, spinner, "Enter valid number", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);

                    //dito nagccheck kapag babaguhin yung value ng quantity tapos iccheck kung may stock pa
                    if (pili == JOptionPane.OK_OPTION)
                        {
                        spin_val = Integer.parseInt(spinner.getValue().toString());
                            {
                            if (spin_val > temp || temp == 0 || spin_val == 1)
                                {
                                JOptionPane.showMessageDialog(null, "Insufficient stock at the moment", "Out of stock!", JOptionPane.WARNING_MESSAGE);
                                }
                            else
                                {
                                String real_sizers = JOptionPane.showInputDialog(null, "Input your desired size.", sizers);
                                String new_sp = cartTable.getValueAt(rowIndex, 3).toString();
                                //set ng values sa row (quantity, size, price, total)
                                cartTable.setValueAt(Integer.parseInt(spinner.getValue().toString()), rowIndex, 1);
                                cartTable.setValueAt(getNewSize(real_sizers), rowIndex, 2);
                                cartTable.setValueAt(getNewSizePrice(), rowIndex, 3);

                                //set ng total after changes
                                int new_price = Integer.parseInt(cartTable.getValueAt(rowIndex, 3).toString());
                                int new_quantity = Integer.parseInt(spinner.getValue().toString());
                                int new_total = new_price * new_quantity;
                                cartTable.setValueAt(new_total, rowIndex, 4);
                                }
                            }
                        }
                    break;
                    }
                case "Red-String-Dress":
                    {

                    String size = cartTable.getValueAt(rowIndex, 2).toString();
                    int temp = stockChecker("name2", size);
                    SpinnerNumberModel sModel = new SpinnerNumberModel(1, 0, temp, 1);
                    JSpinner spinner = new JSpinner(sModel);
                    int pili = JOptionPane.showOptionDialog(null, spinner, "Enter valid number", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);

                    //dito nagccheck kapag babaguhin yung value ng quantity tapos iccheck kung may stock pa
                    if (pili == JOptionPane.OK_OPTION)
                        {
                        spin_val = Integer.parseInt(spinner.getValue().toString());
                            {
                            if (spin_val > temp || temp == 0 || spin_val == 1)
                                {
                                JOptionPane.showMessageDialog(null, "Insufficient stock at the moment", "Out of stock!", JOptionPane.WARNING_MESSAGE);
                                }
                            else
                                {
                                String real_sizers = JOptionPane.showInputDialog(null, "Input your desired size.", sizers);
                                String new_sp = cartTable.getValueAt(rowIndex, 3).toString();
                                //set ng values sa row (quantity, size, price, total)
                                cartTable.setValueAt(Integer.parseInt(spinner.getValue().toString()), rowIndex, 1);
                                cartTable.setValueAt(getNewSize(real_sizers), rowIndex, 2);
                                cartTable.setValueAt(getNewSizePrice(), rowIndex, 3);

                                //set ng total after changes
                                int new_price = Integer.parseInt(cartTable.getValueAt(rowIndex, 3).toString());
                                int new_quantity = Integer.parseInt(spinner.getValue().toString());
                                int new_total = new_price * new_quantity;
                                cartTable.setValueAt(new_total, rowIndex, 4);
                                }
                            }
                        }
                    break;
                    }
                case "Silky-Backless-Tie-Up":
                    {

                    String size = cartTable.getValueAt(rowIndex, 2).toString();
                    int temp = stockChecker("name5", size);
                    SpinnerNumberModel sModel = new SpinnerNumberModel(1, 0, temp, 1);
                    JSpinner spinner = new JSpinner(sModel);
                    int pili = JOptionPane.showOptionDialog(null, spinner, "Enter valid number", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);

                    //dito nagccheck kapag babaguhin yung value ng quantity tapos iccheck kung may stock pa
                    if (pili == JOptionPane.OK_OPTION)
                        {
                        spin_val = Integer.parseInt(spinner.getValue().toString());
                            {
                            if (spin_val > temp || temp == 0 || spin_val == 1)
                                {
                                JOptionPane.showMessageDialog(null, "Insufficient stock at the moment", "Out of stock!", JOptionPane.WARNING_MESSAGE);
                                }
                            else
                                {
                                String real_sizers = JOptionPane.showInputDialog(null, "Input your desired size.", sizers);
                                String new_sp = cartTable.getValueAt(rowIndex, 3).toString();
                                //set ng values sa row (quantity, size, price, total)
                                cartTable.setValueAt(Integer.parseInt(spinner.getValue().toString()), rowIndex, 1);
                                cartTable.setValueAt(getNewSize(real_sizers), rowIndex, 2);
                                cartTable.setValueAt(getNewSizePrice(), rowIndex, 3);

                                //set ng total after changes
                                int new_price = Integer.parseInt(cartTable.getValueAt(rowIndex, 3).toString());
                                int new_quantity = Integer.parseInt(spinner.getValue().toString());
                                int new_total = new_price * new_quantity;
                                cartTable.setValueAt(new_total, rowIndex, 4);
                                }
                            }
                        }
                    break;
                    }
                case "Oversize-Tshirt-Mont.March":
                    {

                    String size = cartTable.getValueAt(rowIndex, 2).toString();
                    int temp = stockChecker("name3", size);
                    SpinnerNumberModel sModel = new SpinnerNumberModel(1, 0, temp, 1);
                    JSpinner spinner = new JSpinner(sModel);
                    int pili = JOptionPane.showOptionDialog(null, spinner, "Enter valid number", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);

                    //dito nagccheck kapag babaguhin yung value ng quantity tapos iccheck kung may stock pa
                    if (pili == JOptionPane.OK_OPTION)
                        {
                        spin_val = Integer.parseInt(spinner.getValue().toString());
                            {
                            if (spin_val > temp || temp == 0 || spin_val == 1)
                                {
                                JOptionPane.showMessageDialog(null, "Insufficient stock at the moment", "Out of stock!", JOptionPane.WARNING_MESSAGE);
                                }
                            else
                                {
                                String real_sizers = JOptionPane.showInputDialog(null, "Input your desired size.", sizers);
                                String new_sp = cartTable.getValueAt(rowIndex, 3).toString();
                                //set ng values sa row (quantity, size, price, total)
                                cartTable.setValueAt(Integer.parseInt(spinner.getValue().toString()), rowIndex, 1);
                                cartTable.setValueAt(getNewSize(real_sizers), rowIndex, 2);
                                cartTable.setValueAt(getNewSizePrice(), rowIndex, 3);

                                //set ng total after changes
                                int new_price = Integer.parseInt(cartTable.getValueAt(rowIndex, 3).toString());
                                int new_quantity = Integer.parseInt(spinner.getValue().toString());
                                int new_total = new_price * new_quantity;
                                cartTable.setValueAt(new_total, rowIndex, 4);
                                }
                            }
                        }
                    break;
                    }
                case "Moon-Graphic-Tee":
                    {

                    String size = cartTable.getValueAt(rowIndex, 2).toString();
                    int temp = stockChecker("name6", size);
                    SpinnerNumberModel sModel = new SpinnerNumberModel(1, 0, temp, 1);
                    JSpinner spinner = new JSpinner(sModel);
                    int pili = JOptionPane.showOptionDialog(null, spinner, "Enter valid number", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);

                    //dito nagccheck kapag babaguhin yung value ng quantity tapos iccheck kung may stock pa
                    if (pili == JOptionPane.OK_OPTION)
                        {
                        spin_val = Integer.parseInt(spinner.getValue().toString());
                            {
                            if (spin_val > temp || temp == 0 || spin_val == 1)
                                {
                                JOptionPane.showMessageDialog(null, "Insufficient stock at the moment", "Out of stock!", JOptionPane.WARNING_MESSAGE);
                                }
                            else
                                {
                                String real_sizers = JOptionPane.showInputDialog(null, "Input your desired size.", sizers);
                                String new_sp = cartTable.getValueAt(rowIndex, 3).toString();
                                //set ng values sa row (quantity, size, price, total)
                                cartTable.setValueAt(Integer.parseInt(spinner.getValue().toString()), rowIndex, 1);
                                cartTable.setValueAt(getNewSize(real_sizers), rowIndex, 2);
                                cartTable.setValueAt(getNewSizePrice(), rowIndex, 3);

                                //set ng total after changes
                                int new_price = Integer.parseInt(cartTable.getValueAt(rowIndex, 3).toString());
                                int new_quantity = Integer.parseInt(spinner.getValue().toString());
                                int new_total = new_price * new_quantity;
                                cartTable.setValueAt(new_total, rowIndex, 4);
                                }
                            }
                        }
                    break;
                    }

                }
            } catch (Exception e)
            {

            }


    }//GEN-LAST:event_UpdateBtnActionPerformed

    private void cartTableMouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_cartTableMouseClicked
    {//GEN-HEADEREND:event_cartTableMouseClicked

    }//GEN-LAST:event_cartTableMouseClicked

    private void cartTableMouseExited(java.awt.event.MouseEvent evt)//GEN-FIRST:event_cartTableMouseExited
    {//GEN-HEADEREND:event_cartTableMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_cartTableMouseExited

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jButton1ActionPerformed
    {//GEN-HEADEREND:event_jButton1ActionPerformed
        Shopping_window sww = new Shopping_window();
        sww.show();
        dispose();

    }//GEN-LAST:event_jButton1ActionPerformed

    private void cartTableFocusGained(java.awt.event.FocusEvent evt)//GEN-FIRST:event_cartTableFocusGained
    {//GEN-HEADEREND:event_cartTableFocusGained
        UpdateBtn.setEnabled(true);
        RemoveBtn.setEnabled(true);
        CheckoutBtn.setEnabled(true);
         SelBtn.setText("Unselect All");
        
    }//GEN-LAST:event_cartTableFocusGained

    private void SelBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelBtnActionPerformed
      if(SelBtn.getText().equals("Select All")){
            cartTable.selectAll();
            SelBtn.setText("Unselect All");
            UpdateBtn.setEnabled(true);
        RemoveBtn.setEnabled(true);
        CheckoutBtn.setEnabled(true);
        }
        
        else{
           cartTable.clearSelection();
           SelBtn.setText("Select All");
           UpdateBtn.setEnabled(false);
        RemoveBtn.setEnabled(false);
        CheckoutBtn.setEnabled(false);
        }
    }//GEN-LAST:event_SelBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[])
        {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try
            {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels())
                {
                if ("Nimbus".equals(info.getName()))
                    {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                    }
                }
            } catch (ClassNotFoundException ex)
            {
            java.util.logging.Logger.getLogger(Cart_window.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            } catch (InstantiationException ex)
            {
            java.util.logging.Logger.getLogger(Cart_window.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            } catch (IllegalAccessException ex)
            {
            java.util.logging.Logger.getLogger(Cart_window.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            } catch (javax.swing.UnsupportedLookAndFeelException ex)
            {
            java.util.logging.Logger.getLogger(Cart_window.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable()
            {
            public void run()
                {
                new Cart_window().setVisible(true);
                }
            });
        }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JButton CheckoutBtn;
    private javax.swing.JButton RemoveBtn;
    private javax.swing.JButton SelBtn;
    private javax.swing.JButton UpdateBtn;
    public static javax.swing.JTable cartTable;
    private javax.swing.JButton jButton1;
    public static javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
    }
